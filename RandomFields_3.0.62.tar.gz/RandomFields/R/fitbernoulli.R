
fit.bernoulli <- function(...) {
  stop("estimation of binary fields not programmed yet")
}
